clear; clc; close all    
counter = 0;
violation_matrix = nan(20,64);
for hypervar1 = [50, 100, 200, 400, 600, 800, 1000, 1200]    
%     counter_var = 1;
    for j = [50, 100, 200, 400, 600, 800, 1000, 1200]
        Matrix = load("Matrix_" + hypervar1+ "_"+j+".csv");
        Matrix = Matrix';
        
        presto_high_cost = load("PRESTO_high_cost_" + hypervar1+ "_"+j+".csv");
        presto_high_cost = presto_high_cost';
        
        presto_low_cost = load("PRESTO_low_cost_" + hypervar1+ "_"+j+".csv");
        presto_low_cost = presto_low_cost';
              
        counter = counter +1;
        violation_matrix(:,counter)=presto_high_cost(:,1);
        
    end
end  
    figure
    positions = [1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 37 38 39 40 41 42 43 44 46 47 48 49 50 51 52 53 55 56 57 58 59 60 61 62 64 65 66 67 68 69 70 71];
    bp = boxplot(violation_matrix, 'positions', positions, 'widths', 0.85);
    ylim([-0.1 15])
    xlim([0.15 72])
    h=gca; 
    h.XAxis.TickLength = [0 0];
    set(gca,'xtick',[mean(positions(1:8)) mean(positions(9:16)) mean(positions(17:24)) mean(positions(25:32)) mean(positions(33:40)) mean(positions(41:48)) mean(positions(49:56)) mean(positions(57:64))]);
    set(gca,'xticklabel',{'50', '100', '200', '400', '600', '800', '1000', '1200'});
    
    color = ['m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w'];
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end

    tickSize = get(gca,'XTickLabel');
    set(gca,'XTickLabel',tickSize,'fontsize',22)
    tickSize = get(gca,'YTickLabel');
    set(gca,'YTickLabel',tickSize,'fontsize',22)

    yl = ylim(); % Find out x location of the y axis.
    % Cover up existing axis with a white line.
    line([0 0.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([8.5 9.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([17.5 18.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([26.5 27.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([35.5 36.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([44.5 45.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([53.5 54.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([62.5 63.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);



%     lg = legend('120h','100h','80h','60h','40h','20h','10h','5h','fontsize',18,'edgecolor','w','Location','bestoutside','Orientation','horizontal');
    hAx=gca;                             
    hAx.XTickLabel=hAx.XTickLabel;
    xlabel("Update threshold  (N)","FontSize",28);
    ylabel("Disruptions","FontSize",28);
%     set(gca,'ygrid','on')
%     lg.Position(1:2) = [.1 .8];

counter = 0;
cost_rate = 2;
        c0 = 10;
violation_matrix = nan(20,64);
for hypervar1 = [50, 100, 200, 400, 600, 800, 1000, 1200]    
%     counter_var = 1;
    for j = [50, 100, 200, 400, 600, 800, 1000, 1200]
        Matrix = load("Matrix_" + hypervar1+ "_"+j+".csv");
        Matrix = Matrix';
        
        presto_high_cost = load("PRESTO_high_cost_" + hypervar1+ "_"+j+".csv");
        presto_high_cost = presto_high_cost';
        
        presto_low_cost = load("PRESTO_low_cost_" + hypervar1+ "_"+j+".csv");
        presto_low_cost = presto_low_cost';
              
        counter = counter +1;
        violation_matrix(:,counter)=(presto_high_cost(:,1)*(cost_rate)+presto_low_cost(:,1))*c0;
        
    end
end  
    figure
    positions = [1 2 3 4 5 6 7 8 10 11 12 13 14 15 16 17 19 20 21 22 23 24 25 26 28 29 30 31 32 33 34 35 37 38 39 40 41 42 43 44 46 47 48 49 50 51 52 53 55 56 57 58 59 60 61 62 64 65 66 67 68 69 70 71];
    bp = boxplot(violation_matrix, 'positions', positions, 'widths', 0.85);
     ylim([430 650])
     xlim([0.15 72])
    h=gca; 
    h.XAxis.TickLength = [0 0];
    set(gca,'xtick',[mean(positions(1:8)) mean(positions(9:16)) mean(positions(17:24)) mean(positions(25:32)) mean(positions(33:40)) mean(positions(41:48)) mean(positions(49:56)) mean(positions(57:64))]);
    set(gca,'xticklabel',{'50', '100', '200', '400', '600', '800', '1000', '1200'});
    
    color = ['m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w','m', 'c', 'r', 'b', 'g', 'y', 'k', 'w'];
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        hl(j)=patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end

    tickSize = get(gca,'XTickLabel');
    set(gca,'XTickLabel',tickSize,'fontsize',22)
    tickSize = get(gca,'YTickLabel');
    set(gca,'YTickLabel',tickSize,'fontsize',22)

    yl = ylim(); % Find out x location of the y axis.
    % Cover up existing axis with a white line.
    line([0 0.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([8.5 9.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([17.5 18.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([26.5 27.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([35.5 36.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([44.5 45.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([53.5 54.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);
    hold on
    line([62.5 63.5], [yl(1), yl(1)], 'color', 'w', 'LineWidth', 2);


%     labels = {'120h','100h','80h','60h','40h','20h','10h','5h'};
%     legend(flip(hl), flip(labels),'fontsize',25,'edgecolor','w','Location','bestoutside','Orientation','horizontal');

%     lg = legend('120h','100h','80h','60h','40h','20h','10h','5h','fontsize',18,'edgecolor','w','Location','bestoutside','Orientation','horizontal');

    hAx=gca;                             
    hAx.XTickLabel=hAx.XTickLabel;
    xlabel("Update threshold (N)","FontSize",28);
    ylabel("Cost","FontSize",28);
%     lg.Position(1:2) = [.1 .8];
%     set(gca,'ygrid','on')

